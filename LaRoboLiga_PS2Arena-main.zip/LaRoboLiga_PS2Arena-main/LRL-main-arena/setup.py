from setuptools import setup

setup(name='LRL_main_arena',
      version='0.0.1',
      install_requires=['gym', 'pybullet', 'opencv-contrib-python', 'numpy']
)